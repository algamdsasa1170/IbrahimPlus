
function generateAd() {
    const input = document.getElementById("description").value.trim();
    const output = document.getElementById("output");

    if (!input) {
        output.innerHTML = "❗ الرجاء كتابة وصف الخدمة أولاً.";
        return;
    }

    let result = "";
    let rating = "⚠️";

    if (input.includes("تصميم")) {
        result = "✨ نقدم لك تصميماً مميزاً يلفت الأنظار ويعبر عنك باحترافية. اطلب الآن!";
        rating = "⭐️⭐️⭐️⭐️⭐️ ممتاز (عاطفي وجذاب)";
    } else if (input.includes("زيادة متابعين")) {
        result = "📈 زد عدد متابعينك بأسلوب آمن وفعّال باستخدام أدواتنا المعتمدة.";
        rating = "⭐️⭐️⭐️⭐️ قوي (مباشر ومقنع)";
    } else if (input.length < 20) {
        result = "💬 نرجو وصف الخدمة بشكل أوضح للحصول على إعلان مثالي.";
        rating = "⭐️ ضعيف (قصير جداً)";
    } else {
        result = "✅ خدمتك مميزة! يمكننا توليد إعلان مخصص لها، تواصل معنا لتخصيص أكثر.";
        rating = "⭐️⭐️⭐️ جيد (قابل للتطوير)";
    }

    output.innerHTML = `<p><strong>📢 إعلانك:</strong><br>${result}</p><p><strong>📊 تقييم الجودة:</strong> ${rating}</p>`;
}
